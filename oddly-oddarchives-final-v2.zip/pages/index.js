export default function Home() {
  return (
    <main style={{ backgroundColor: 'black', color: 'white', padding: '2rem' }}>
      <h1 style={{ fontFamily: 'serif', fontSize: '3rem', textAlign: 'center' }}>Oddly Odd Archives</h1>
      <p style={{ textAlign: 'center', color: '#ccc' }}>15 Articles – Some with images, all with critical sourcing.</p>
    </main>
  );
}